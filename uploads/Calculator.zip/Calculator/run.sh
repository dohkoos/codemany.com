#!/bin/sh
java -cp .:./antlr-4.5.1-complete.jar:$CLASSPATH $*
