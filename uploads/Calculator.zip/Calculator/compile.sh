#!/bin/sh
javac -cp .:./antlr-4.5.1-complete.jar:$CLASSPATH $*
