#include "MainApp.h"
#include "MainFrame.h"

#include <wx/dir.h>
#include <wx/xrc/xh_menu.h>

IMPLEMENT_APP(MainApp)

bool MainApp::OnInit()
{
    wxXmlResource* pResource = wxXmlResource::Get();
    pResource->AddHandler(new wxMenuBarXmlHandler);
    pResource->AddHandler(new wxMenuXmlHandler);
    pResource->Load(wxT("resources/MenuBar.xrc"));

    MainFrame* frame = new MainFrame(wxT("Hello wxWidgets"));
    SetTopWindow(frame);
    frame->Show(true);
    return true;
}
