#include "MainFrame.h"

#include <wx/wx.h>
#include <wx/log.h>
#include <wx/msgdlg.h>
#include <wx/menu.h>
#include <wx/xrc/xh_menu.h>

enum
{
    wxID_LANGUAGE_LOWEST = wxID_HIGHEST + 1,
    wxID_LANGUAGE_HIGHEST = wxID_LANGUAGE_LOWEST + wxLANGUAGE_USER_DEFINED - wxLANGUAGE_DEFAULT,
};

BEGIN_EVENT_TABLE(MainFrame, wxFrame)
    EVT_MENU(XRCID("wxID_CLOSE"),  MainFrame::OnClose)
    EVT_MENU(XRCID("wxID_ABOUT"), MainFrame::OnAbout)

    EVT_MENU_RANGE(wxID_LANGUAGE_LOWEST, wxID_LANGUAGE_HIGHEST, MainFrame::OnChooseLanguage)
END_EVENT_TABLE()

MainFrame::MainFrame(const wxString& title) : wxFrame(NULL, wxID_ANY, title)
{
    m_menuBar = NULL;

    InitMenuBar();
}

bool MainFrame::InitMenuBar()
{
    if (m_menuBar)
    {
        SetMenuBar(NULL);
        delete m_menuBar;
    }
    m_menuBar = wxXmlResource::Get()->LoadMenuBar(wxT("ID_MENUBAR"));
    if (!m_menuBar)
    {
        wxLogError(wxT("Cannot load main menu from resource file"));
        return false;
    }

    wxMenuItem* menuItem = m_menuBar->FindItem(XRCID("wxID_LANGUAGE"));
    if (menuItem)
    {
        wxMenu* subMenu = menuItem->GetSubMenu();
        subMenu->AppendRadioItem(wxID_LANGUAGE_LOWEST + 1, wxT("English"));
        subMenu->AppendRadioItem(wxID_LANGUAGE_LOWEST + 2, wxT("Chinese(Simplified)"));
    }

    SetMenuBar(m_menuBar);

    return true;
}

// event handlers
void MainFrame::OnClose(wxCommandEvent& WXUNUSED(event))
{
    Close(true);
}

void MainFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{
    wxString msg = wxString::Format(wxT("This is the about dialog of XML resources demo.\r\nWelcome to %s."), wxVERSION_STRING);
    wxMessageBox(msg, wxT("About XML resources demo"), wxOK | wxICON_INFORMATION, this);
}

void MainFrame::OnChooseLanguage(wxCommandEvent& event)
{
    wxString label = m_menuBar->GetLabel(event.GetId());
    wxString msg = wxString::Format(wxT("You have select %s language."), label);
    wxMessageBox(msg, wxT("About XML resources demo"), wxOK | wxICON_INFORMATION, this);
}
