#ifndef __MAINFRAME_H__
#define __MAINFRAME_H__

#include <wx/frame.h>

class MainFrame : public wxFrame
{
public:
    MainFrame(const wxString& title);

    // event handlers (these functions should _not_ be virtual)
    void OnClose(wxCommandEvent& WXUNUSED(event));
    void OnAbout(wxCommandEvent& WXUNUSED(event));
    void OnChooseLanguage(wxCommandEvent& event);

protected:
    bool InitMenuBar();

    wxMenuBar* m_menuBar;

private:
    // any class wishing to process wxWidgets events must use this macro
    DECLARE_EVENT_TABLE()
};

#endif
