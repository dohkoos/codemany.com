#ifndef __MAINFRAME_H__
#define __MAINFRAME_H__

#include <wx/minifram.h>

class MainFrame : public wxMiniFrame
{
public:
    MainFrame(const wxPoint& pos, const wxSize& size);

protected:
    void OnMouseMove(wxMouseEvent& event);
    void OnMouseLeftDown(wxMouseEvent& event);
    void OnMouseLeftUp(wxMouseEvent& WXUNUSED(event));
    void OnDoubleClick(wxMouseEvent& WXUNUSED(event));

    wxPoint m_delta;

private:
    DECLARE_EVENT_TABLE()
};

#endif
