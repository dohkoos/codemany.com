#include "MainApp.h"
#include "MainFrame.h"

IMPLEMENT_APP(MainApp)

bool MainApp::OnInit()
{
    MainFrame* frame = new MainFrame(wxDefaultPosition, wxSize(38, 38));
    SetTopWindow(frame);
    frame->Show(true);
    return true;
}
