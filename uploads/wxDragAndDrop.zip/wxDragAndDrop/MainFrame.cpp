#include "MainFrame.h"

BEGIN_EVENT_TABLE(MainFrame, wxMiniFrame)
    EVT_MOTION(MainFrame::OnMouseMove)
    EVT_LEFT_DOWN(MainFrame::OnMouseLeftDown)
    EVT_LEFT_UP(MainFrame::OnMouseLeftUp)
    EVT_LEFT_DCLICK (MainFrame::OnDoubleClick)
END_EVENT_TABLE()

MainFrame::MainFrame(const wxPoint& pos, const wxSize& size) : wxMiniFrame(NULL, wxID_ANY, wxEmptyString, pos, size)
{
    SetWindowStyleFlag(wxFRAME_NO_TASKBAR);
}

void MainFrame::OnMouseMove(wxMouseEvent& event)
{
    if (event.Dragging() && event.LeftIsDown())
    {
        wxPoint pt = ClientToScreen(event.GetPosition());
        int x = pt.x - m_delta.x;
        int y = pt.y - m_delta.y;
        Move(x, y);
    }
}

void MainFrame::OnDoubleClick(wxMouseEvent& WXUNUSED(event))
{
    Close(true);
}

void MainFrame::OnMouseLeftDown(wxMouseEvent& event)
{
    CaptureMouse();
    wxPoint pt = ClientToScreen(event.GetPosition());
    wxPoint origin = GetPosition();
    int dx = pt.x - origin.x;
    int dy = pt.y - origin.y;
    m_delta = wxPoint(dx, dy);
}

void MainFrame::OnMouseLeftUp(wxMouseEvent& WXUNUSED(event))
{
    if (HasCapture())
    {
        ReleaseMouse();
    }
}
