#ifndef __MAINAPP_H__
#define __MAINAPP_H__

#include <wx/wx.h>

class MainApp : public wxApp
{
public:
    virtual bool OnInit();
};

#endif
