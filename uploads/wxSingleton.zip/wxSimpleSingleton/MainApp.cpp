#include "MainApp.h"
#include "MainFrame.h"

IMPLEMENT_APP(MainApp)

bool MainApp::OnInit()
{
    wxString name = wxString::Format(wxT("MainApp-%s"), wxGetUserId().GetData());
    m_checker = new wxSingleInstanceChecker(name);
    if (m_checker->IsAnotherRunning())
    {
        wxLogError(wxT("Another program instance is already running, aborting."));
        return false;
    }

    MainFrame* frame = new MainFrame(wxT("Hello wxWidgets"));
    SetTopWindow(frame);
    frame->Show();

    return true;
}

int MainApp::OnExit()
{
    delete m_checker;
    return 0;
}
