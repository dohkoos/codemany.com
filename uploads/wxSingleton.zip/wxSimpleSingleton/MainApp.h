#ifndef __MAINAPP_H__
#define __MAINAPP_H__

#include <wx/wx.h>
#include <wx/snglinst.h>

class MainApp : public wxApp
{
public:
    virtual bool OnInit();
    virtual int OnExit();

protected:
    bool SingleInstanceChecker();

    wxSingleInstanceChecker* m_checker;
};

#endif
