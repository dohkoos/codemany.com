#ifndef __MAINFRAME_H__
#define __MAINFRAME_H__

#include <wx/frame.h>

class MainFrame : public wxFrame
{
public:
    MainFrame(const wxString& title);
};

#endif
