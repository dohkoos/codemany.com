#include "MainApp.h"
#include "MainFrame.h"

const wxString szServer = wxT("wxMainApp");
const wxString szTopic = wxT("single-instance");

class AppServer : public wxServer
{
public:
    virtual wxConnectionBase* OnAcceptConnection(const wxString& topic);
};

class AppClient : public wxClient
{
public:
    virtual wxConnectionBase* OnMakeConnection();
};

class AppConnection : public wxConnection
{
public:
    virtual bool OnExecute(const wxString& WXUNUSED(topic), wxChar* WXUNUSED(data),
        int WXUNUSED(size), wxIPCFormat WXUNUSED(format));
};

wxConnectionBase* AppServer::OnAcceptConnection(const wxString& topic)
{
    if (topic.Lower() == szTopic)
    {
        wxWindowList::Node* node = wxTopLevelWindows.GetFirst();
        while (node)
        {
            wxDialog* dialog = wxDynamicCast(node->GetData(), wxDialog);
            if (dialog && dialog->IsModal())
            {
                return false;
            }
            node = node->GetNext();
        }
        return new AppConnection();
    }
    else
        return NULL;
}

wxConnectionBase* AppClient::OnMakeConnection()
{
    return new AppConnection();
}

bool AppConnection::OnExecute(const wxString& WXUNUSED(topic), wxChar* WXUNUSED(data),
                              int WXUNUSED(size), wxIPCFormat WXUNUSED(format))
{
    wxFrame* frame = wxDynamicCast(wxGetApp().GetTopWindow(), wxFrame);
    if (frame)
    {
        frame->Restore();    // ����Ҫ����䣬��Ȼ����������С��ʱ���Ͳ��ܱ��ᵽǰ̨
        frame->Raise();
    }
    return true;
}

//////////////////////////////////////////////////////////////////////////
IMPLEMENT_APP(MainApp)

bool MainApp::OnInit()
{
    wxString name = wxString::Format(wxT("MainApp-%s"), wxGetUserId().GetData());
    m_checker = new wxSingleInstanceChecker(name);
    if (!m_checker->IsAnotherRunning())
    {
        m_server = new AppServer();
        if (!m_server->Create(szServer))
        {
            wxLogDebug(wxT("Failed to create an IPC service."));
            return false;
        }
    }
    else
    {
        AppClient* client = new AppClient();
        wxString hostName = wxT("localhost");
        wxConnectionBase* connection = client->MakeConnection(hostName, szServer, szTopic);
        if (connection)
        {
            connection->Execute(wxEmptyString);
            connection->Disconnect();
            delete connection;
        }
        else
        {
            wxMessageBox(wxT("Sorry, the existing instance may be too busy to respond.\nPlease close any open dialogs and retry."),
                wxT("wxMainApp"), wxICON_INFORMATION | wxOK);
        }
        delete client;    // ���û����䣬����Debug�汾ʱ�ͻ����"wxDDEServerObjects.empty() && wxDDEClientObjects.empty()" failed in wxDDECleanUp()�Ի���

        return false;
    }

    MainFrame* frame = new MainFrame(wxT("Hello wxWidgets"));
    SetTopWindow(frame);
    frame->Show(true);

    return true;
}

int MainApp::OnExit()
{
    delete m_checker;
    delete m_server;

    return 0;
}
