#include <windows.h>
#include <shlobj.h>
#include <stdio.h>
#include "resource.h"

TCHAR szSelDir[MAX_PATH];
char SIGNATURE[] = {0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x53, 0x0D, 0x0A};
DWORD SIGNATURE_LENGTH = 16;

BOOL IsSignature(char szBuffer[])
{
    for (DWORD i = 0; i < SIGNATURE_LENGTH; i++) {
        if (szBuffer[i] != SIGNATURE[i]) {
            return FALSE;
        }
    }
    return TRUE;
}

VOID WINAPI BackupMailBox(LPVOID param)
{
    TCHAR *szFileName = (TCHAR *)param;

    // ����������洢�ļ���Ӧ���ļ��У�����������eml�ʼ��ļ������ڸ��ļ�����
    TCHAR szNewDir[MAX_PATH];
    lstrcpy(szNewDir, szSelDir);
    lstrcat(szNewDir, L"\\");
    lstrcat(szNewDir, szFileName);
    lstrcat(szNewDir, L".bak");
    CreateDirectory(szNewDir, NULL);

    // ������洢�ļ�������׺��ΪBOX���ļ�
    TCHAR szBoxFilePath[MAX_PATH];
    lstrcpy(szBoxFilePath, szSelDir);
    lstrcat(szBoxFilePath, L"\\");
    lstrcat(szBoxFilePath, szFileName);
    HANDLE hReadFile = CreateFile(szBoxFilePath,
                                    GENERIC_READ,
                                    FILE_SHARE_READ,
                                    NULL,
                                    OPEN_ALWAYS,
                                    FILE_ATTRIBUTE_NORMAL,
                                    NULL);

    char szBuffer[64];
    UINT iCount = 0;
    DWORD nBytesRead, nBytesWrite;

    BOOL bResult = ReadFile(hReadFile, &szBuffer, 1, &nBytesRead, NULL);
    while (bResult && nBytesRead != 0)
    {
        if (szBuffer[0] == SIGNATURE[0])
        {
            SetFilePointer(hReadFile, -1, NULL, FILE_CURRENT);
            ReadFile(hReadFile, &szBuffer, SIGNATURE_LENGTH, &nBytesRead, NULL);
            if (IsSignature(szBuffer))
            {
                iCount++;
                TCHAR szNewEmlPath[MAX_PATH];
                lstrcpy(szNewEmlPath, szNewDir);
                lstrcat(szNewEmlPath, L"\\mail");
                TCHAR szTemp[10] = {0};
                wsprintf(szTemp, L"%06i", iCount);
                lstrcat(szNewEmlPath, szTemp);
                lstrcat(szNewEmlPath, L".eml");
                HANDLE hWriteFile = CreateFile(szNewEmlPath,
                                        GENERIC_WRITE,
                                        FILE_SHARE_READ,
                                        NULL,
                                        CREATE_ALWAYS,
                                        FILE_ATTRIBUTE_NORMAL,
                                        NULL);
                bResult = ReadFile(hReadFile, &szBuffer, 1, &nBytesRead, NULL);
                while (bResult && nBytesRead != 0 && szBuffer[0] != SIGNATURE[0])
                {
                    WriteFile(hWriteFile, szBuffer, 1, &nBytesWrite, NULL);
                    bResult = ReadFile(hReadFile, &szBuffer, 1, &nBytesRead, NULL);
                }
                CloseHandle(hWriteFile);
            }
        }
    }
    CloseHandle(hReadFile);
}

LRESULT CALLBACK DlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    HICON hIcon;

    switch (uMsg)
    {
    case WM_INITDIALOG:
        hIcon = LoadIcon((HINSTANCE)GetWindowLong(hDlg, GWL_HINSTANCE), MAKEINTRESOURCE(IDI_ICON));
//      SendMessage(hDlg, WM_SETICON, TRUE, (LPARAM)hIcon); // ʹ��16*16��ͼ��
        SendMessage(hDlg, WM_SETICON, FALSE, (LPARAM)hIcon);    // ʹ��32*32��ͼ��
        break;

    case WM_COMMAND:
        switch (LOWORD(wParam))
        {
        case IDC_BACKUP:
            HANDLE hFind;
            WIN32_FIND_DATA ffd;

            GetDlgItemText(hDlg, IDC_DIR, szSelDir, MAX_PATH);  // ����ֱ�ӽ�·�����뵽edit�ؼ��е����
            if (szSelDir[0] == '\0')
            {
                MessageBox(hDlg, TEXT("The directory cannot be left blank."), TEXT("Warnning"), MB_ICONWARNING | MB_OK);
                return FALSE;
            }

            EnableWindow(GetDlgItem(hDlg, IDC_BACKUP), FALSE);
            EnableWindow(GetDlgItem(hDlg, IDC_DIR), FALSE);
            EnableWindow(GetDlgItem(hDlg, IDC_BROWSE), FALSE);

            SetCurrentDirectory(szSelDir);  // ���õ�ǰ���ҵ�Ŀ¼
            hFind = FindFirstFile(TEXT("*.BOX"), &ffd); // ���Һ�׺��ΪBOX���ļ�
            if (hFind != INVALID_HANDLE_VALUE)
            {
                do
                {
                    HANDLE hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)BackupMailBox, (VOID *)&ffd.cFileName, 0, NULL);
                    WaitForSingleObject(hThread, WAIT_TIMEOUT);
                    CloseHandle(hThread);   // ��Ϊ���ǲ���ʹ���߳̾����Ҫ�����ر����Ա����ڴ�й©
                } while (FindNextFile(hFind, &ffd) != 0);
            }
            FindClose(hFind);

            EnableWindow(GetDlgItem(hDlg, IDC_BACKUP), TRUE);
            EnableWindow(GetDlgItem(hDlg, IDC_DIR), TRUE);
            EnableWindow(GetDlgItem(hDlg, IDC_BROWSE), TRUE);

            return TRUE;

        case IDCANCEL:
            PostQuitMessage(0);
            return TRUE;

        case IDC_BROWSE:
            BROWSEINFO bfo = {0};
            bfo.hwndOwner = hDlg;
            bfo.ulFlags = BIF_RETURNONLYFSDIRS;
            LPITEMIDLIST pidl = SHBrowseForFolder(&bfo);
            if (pidl != NULL)
            {
                SHGetPathFromIDList(pidl, szSelDir);
                SetDlgItemText(hDlg, IDC_DIR, szSelDir);
            }
            return TRUE;
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
    }
    return FALSE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
    MSG msg;
    HWND hDlg;

    hDlg = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_DIALOG), NULL, (DLGPROC)DlgProc);
    ShowWindow(hDlg, SW_SHOW);
    UpdateWindow(hDlg);

    while (GetMessage(&msg, NULL, 0, 0))
    {
        if (!IsDialogMessage(hDlg, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return msg.wParam;
}
