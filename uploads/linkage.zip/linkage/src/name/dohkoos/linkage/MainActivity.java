package name.dohkoos.linkage;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        loadSpinner();
    }

    private void loadSpinner() {
        Spinner provinceSpinner = (Spinner)findViewById(R.id.province_spinner);
        provinceSpinner.setPrompt("请选择省份");
        provinceSpinner.setAdapter(getSpinnerAdapter(999999));
        provinceSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Spinner citySpinner = (Spinner)findViewById(R.id.city_spinner);
                citySpinner.setPrompt("请选择城市");
                citySpinner.setAdapter(getSpinnerAdapter(id));
                citySpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        Spinner countySpinner = (Spinner)findViewById(R.id.county_spinner);
                        countySpinner.setPrompt("请选择县区");
                        countySpinner.setAdapter(getSpinnerAdapter(id));
                        countySpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                Cursor cursor = (Cursor)parent.getSelectedItem();
                                if (cursor != null) {
                                    String country = cursor.getString(cursor.getColumnIndex("region"));
                                    Toast.makeText(MainActivity.this, country + " " + id, Toast.LENGTH_LONG).show();
                                }
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {
                            }
                        });
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private SpinnerAdapter getSpinnerAdapter(long code) {
        DBHelper helper = DBHelper.getInstance(this);
        SpinnerAdapter adapter = helper.getListByParentCode(this, String.valueOf(code));
        helper.close();
        return adapter;
    }
}
