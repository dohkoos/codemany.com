

#include "righttreeitemdata.h"

CRightTreeItemData::CRightTreeItemData( int ndata )
{
    m_nData = ndata;
}

int CRightTreeItemData::GetData()
{
    return m_nData;
}

