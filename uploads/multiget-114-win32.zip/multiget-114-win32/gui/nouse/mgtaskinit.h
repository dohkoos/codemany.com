
#ifndef _MG_TASK_INIT_H
#define _MG_TASK_INIT_H

#include <wx/wx.h>
#include <wx/thread.h>
#include <string>
#include "mgurlparser.h"

class CMgSingleTask;

class CMgTaskInit : public wxThread
{

public:
    CMgTaskInit( CMgSingleTask* parent, wxThreadKind kind = wxTHREAD_DETACHED );
    virtual ~CMgTaskInit();
    void* Entry();
    void OutMsg( std::string str, int type );
    void Cancel(); //不同于KILL，在可以的时候才取消线程，否则会等待可以的时候

protected:
    CMgSingleTask* m_pParent;
    CUrlParser upar;
    wxMutex m_CancelLock;
};

#endif

