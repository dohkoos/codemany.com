/*
2006/09/10
*/


#include "mgtaskinit.h"
#include "mgsingletask.h"
#include "mgftpants.h"
#include "mghttpants.h"
#include "mgftpinfo.h"
#include "mghttpinfo.h"
#include "mgtaskinit.h"
#include "mgfilemanager.h"
#include <string>
#include <vector>

CMgTaskInit::CMgTaskInit(
    CMgSingleTask* parent,
    wxThreadKind kind
)
        : wxThread( kind )
{
    m_pParent = parent;
}

CMgTaskInit::~CMgTaskInit()
{}

//取消线程运行
void CMgTaskInit::Cancel()
{
    if ( IsAlive() )
    {
        m_CancelLock.Lock();
        Kill();
    }
}


void* CMgTaskInit::Entry()
{
    //锁定m_CancelLock，相当于设定不可取消的状态
    OutMsg( "init running...", 3 );

    std::vector<std::string> cookie; //for http

again:

    m_CancelLock.Lock();

    if ( !upar.SetUrl( m_pParent->m_sUrl ) )
    {
        //m_CancelLock.Lock();
        m_pParent->m_bInitAlive = false;
        m_pParent->FinishTask( _TASK_ERROR );
        m_CancelLock.Unlock();
        return ( NULL );
    }

    //任务参数
    //m_CancelLock.Lock();
    m_pParent->m_Server = upar.GetServer();

    m_pParent->m_ServerPort = upar.GetPort();

    m_pParent->m_Username = upar.GetUser();

    m_pParent->m_Password = upar.GetPass();

    m_pParent->m_EscFilePathName = upar.GetEscFilePathName(); //文件名

    m_CancelLock.Unlock();

    if ( upar.GetUrlType() == 0 )   //ftp
    {
        m_CancelLock.Lock();
        m_pParent->m_pFtpInfo = new CMgFtpInfo(
                                    m_pParent,
                                    m_pParent->m_Server,
                                    m_pParent->m_ServerPort,
                                    m_pParent->m_Username,
                                    m_pParent->m_Password,
                                    m_pParent->m_EscFilePathName
                                );
        //set proxy here

        if ( m_pParent->m_bUseProxy )
        {
            m_pParent->m_pFtpInfo->SetProxy(
                m_pParent->m_Proxy, m_pParent->m_ProxyPort,
                m_pParent->m_ProxyUser, m_pParent->m_ProxyPass, m_pParent->m_ProxyVersion );
        }

        if ( m_pParent->m_bUseFtpProxy )
        {
            m_pParent->m_pFtpInfo->SetFtpProxy(
                m_pParent->m_FtpProxy, m_pParent->m_FtpProxyPort );
        }

        m_CancelLock.Unlock();
        //go
        DBGOUT( "test before getinfo" );

        if ( !m_pParent->m_pFtpInfo->GetInfo() ) //这个过程比较长，影响停止任务的速度
        {
            DBGOUT( "after getinfo" );
            m_CancelLock.Lock();
            delete m_pParent->m_pHttpInfo;
            m_pParent->m_pHttpInfo = NULL;
            m_pParent->FinishTask( _TASK_ERROR );
            m_pParent->m_bInitAlive = false;
            m_CancelLock.Unlock();
            return ( NULL );
        }

        DBGOUT( "after getinfo" );

        m_pParent->m_nFileLen = m_pParent->m_pFtpInfo->FileSize();
        bool bresume = m_pParent->m_pFtpInfo->IsResume();

        m_CancelLock.Lock();
        delete m_pParent->m_pFtpInfo;
        m_pParent->m_pFtpInfo = NULL;
        m_CancelLock.Unlock();

        if ( m_pParent->m_nFileLen == -1 || !bresume )
        {
            //DBGOUT( "服务器不允许续传，设置下载线程为1" );
            m_pParent->m_nAnts = 1;
            //FinishTask(_TASK_ERROR);
            //InitThreadQuit();
        }


        m_CancelLock.Lock();
        m_pParent->m_pFM = new CMgFileManager(
                               m_pParent, m_pParent->m_sFilename, m_pParent->m_sSavePath, m_pParent->m_nFileLen );
        m_pParent->m_bAfterFM = true;
        m_CancelLock.Unlock();

        if ( !m_pParent->m_pFM->CheckFile() )
        {
            m_CancelLock.Lock();
            delete m_pParent->m_pFM;
            m_pParent->m_pFM = NULL;
            //m_pParent->m_bInitAlive=false;
            m_pParent->FinishTask( _TASK_ERROR );
            m_pParent->m_bInitAlive = false;
            m_CancelLock.Unlock();
            return ( NULL );
        }



        m_CancelLock.Lock();

        for ( int i = 0;i < m_pParent->m_nAnts;i++ )
        {
            m_pParent->m_ftpAnts[ i ] = new CMgFtpAnts(
                                            m_pParent,
                                            i + 1,
                                            m_pParent->m_Server,
                                            m_pParent->m_ServerPort,
                                            m_pParent->m_Username,
                                            m_pParent->m_Password,
                                            m_pParent->m_EscFilePathName,
                                            m_pParent->m_pFM );

            //if need proxy, make here

            if ( m_pParent->m_bUseProxy )
            {
                m_pParent->m_ftpAnts[ i ] ->SetProxy(
                    m_pParent->m_Proxy, m_pParent->m_ProxyPort,
                    m_pParent->m_ProxyUser, m_pParent->m_ProxyPass, m_pParent->m_ProxyVersion );
            }

            if ( m_pParent->m_bUseFtpProxy )
            {
                m_pParent->m_ftpAnts[ m_pParent->m_nAnts ] ->SetFtpProxy(
                    m_pParent->m_FtpProxy, m_pParent->m_FtpProxyPort );
            }

            m_pParent->m_ftpAnts[ i ] ->Go();

        }

        m_pParent->m_nRunningAnts = m_pParent->m_nAnts;
        //m_pParent->m_bInitAlive=false;
        m_pParent->m_nTaskType = 1; //ftp type
        m_pParent->m_bInitAlive = false;
        m_CancelLock.Unlock();
        return ( NULL );

    } //ftp
    else if ( upar.GetUrlType() == 1 )
    { //http
        m_CancelLock.Lock();

        m_pParent->m_ReferServer = upar.GetServer();
        m_pParent->m_Refer = upar.GetRefer();

        m_pParent->m_pHttpInfo =
            new CMgHttpInfo( m_pParent, m_pParent->m_EscFilePathName, m_pParent->m_Server,
                             m_pParent->m_Server, upar.GetRefer(), m_pParent->m_ServerPort );


        if ( m_pParent->m_bUseProxy )
        {
            m_pParent->m_pHttpInfo->SetProxy(
                m_pParent->m_Proxy, m_pParent->m_ProxyPort,
                m_pParent->m_ProxyUser, m_pParent->m_ProxyPass, m_pParent->m_ProxyVersion );
        }

        if ( m_pParent->m_bUseHttpProxy )
        {
            m_pParent->m_pHttpInfo->SetHttpProxy(
                m_pParent->m_HttpProxy, m_pParent->m_HttpProxyPort );
        }

        m_CancelLock.Unlock();

        DBGOUT( "test before getinfo" );

        if ( !m_pParent->m_pHttpInfo->GetInfo() )  //长过程，允许被杀
        { //error when get info.
            DBGOUT( "after getinfo" );
            m_CancelLock.Lock();
            delete m_pParent->m_pHttpInfo;
            m_pParent->m_pHttpInfo = NULL;
            //m_pParent->m_bInitAlive=false;
            m_pParent->FinishTask( _TASK_ERROR );
            m_pParent->m_bInitAlive = false;
            m_CancelLock.Unlock();
            return ( NULL );
        }

        DBGOUT( "after getinfo" );

        m_CancelLock.Lock();

        if ( m_pParent->m_pHttpInfo->IsRedirect() )
        {
            m_pParent->m_sUrl = m_pParent->m_pHttpInfo->GetRedirect();

            DBGOUT( "Redirect to:" << m_pParent->m_sUrl );

            delete m_pParent->m_pHttpInfo;
            m_pParent->m_pHttpInfo = NULL;

            //跳转后就不再用原来的名字了。

            if ( upar.SetUrl( m_pParent->m_sUrl ) )
            {
                if ( !upar.GetFileName().empty() )
                    m_pParent->m_sFilename = upar.GetFileName();
            }

            m_CancelLock.Unlock();
            goto again;
        }


        for ( int coo = 0; coo < m_pParent->m_pHttpInfo->GetCookieNum(); coo++ )
        {
            DBGOUT( m_pParent->m_pHttpInfo->GetCookie( coo ) );
            cookie.push_back( m_pParent->m_pHttpInfo->GetCookie( coo ) );
        }


        m_pParent->m_nFileLen = m_pParent->m_pHttpInfo->GetFileSize();

        delete m_pParent->m_pHttpInfo;
        m_pParent->m_pHttpInfo = NULL;


        if ( m_pParent->m_nFileLen == -1 )
        { //no length get

            m_pParent->m_nAnts = 1;
            //FinishTask( _TASK_ERROR );
            //pthread_exit( 0 );
        }


        //pthread_setcancelstate ( PTHREAD_CANCEL_DISABLE, &oldstate );
        m_pParent->m_pFM = new CMgFileManager (
                               m_pParent, m_pParent->m_sFilename, m_pParent->m_sSavePath, m_pParent->m_nFileLen );

        //pthread_setcancelstate ( oldstate, NULL );
        m_pParent->m_bAfterFM = true;

        if ( !m_pParent->m_pFM->CheckFile() )  //长过程，不允许被杀
        {

            delete m_pParent->m_pFM;
            m_pParent->m_pFM = NULL;
            //m_pParent->m_bInitAlive=false;
            m_pParent->FinishTask( _TASK_ERROR );
            m_pParent->m_bInitAlive = false;
            m_CancelLock.Unlock();
            return ( NULL );
        }




        for ( int i = 0;i < m_pParent->m_nAnts;i++ )
        {
            //not run when construct 2006/09/03
            m_pParent->m_httpAnts[ i ] = new CMgHttpAnts(
                                             m_pParent,
                                             i + 1,
                                             m_pParent->m_Server,
                                             m_pParent->m_ServerPort,
                                             m_pParent->m_Server,
                                             m_pParent->m_EscFilePathName,
                                             upar.GetRefer(),
                                             m_pParent->m_pFM );

            if ( !cookie.empty() )
            {
                for ( int coo = 0; coo < int( cookie.size() ); coo++ )
                {
                    m_pParent->m_httpAnts[ i ] ->AddCookie( cookie[ coo ] );
                }
            }

            //if need proxy, make here

            if ( m_pParent->m_bUseProxy )
            {
                m_pParent->m_pHttpInfo->SetProxy(
                    m_pParent->m_Proxy, m_pParent->m_ProxyPort,
                    m_pParent->m_ProxyUser, m_pParent->m_ProxyPass, m_pParent->m_ProxyVersion );

            }

            if ( m_pParent->m_bUseHttpProxy )
            {
                m_pParent->m_httpAnts[ m_pParent->m_nAnts ] ->SetHttpProxy(
                    m_pParent->m_HttpProxy, m_pParent->m_HttpProxyPort );
            }

            m_pParent->m_httpAnts[ i ] ->Go(); //run thread
        }

        m_pParent->m_nRunningAnts = m_pParent->m_nAnts;
        //m_pParent->m_bInitAlive=false;
        m_pParent->m_nTaskType = 2; //http 类
        m_pParent->m_bInitAlive = false;
        m_CancelLock.Unlock();
        return ( NULL );

    } //http
    else
    {
        //m_pParent->m_bInitAlive=false;
        m_pParent->FinishTask( _TASK_ERROR );
        m_pParent->m_bInitAlive = false;
        return ( NULL );
    }

    OutMsg( "init quiting...", 3 );
    //m_pParent->m_bInitAlive=false;
    return NULL;
}

void CMgTaskInit::OutMsg( std::string str, int type )
{
    m_pParent->OutMsg( -1, str, type );
}

