/***************************************************************************
*            mgnewtaskdlg.cpp
*
*  Mon Sep 18 14:16:13 2006
*  Copyright  2006  liubin,china
*  Email multiget@gmail.com
****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#include "mgnewtaskdlg.h"
#include "mainframe.h"
#include "mgapp.h"
#include "mgurlparser.h"

#include <wx/valgen.h>

DEFINE_EVENT_TYPE( mgID_PICKPATH )
DEFINE_EVENT_TYPE( mgID_SPINCTRL )

BEGIN_EVENT_TABLE( CNewTaskDlg, wxDialog )
EVT_BUTTON( mgID_PICKPATH, CNewTaskDlg::OnPickPath )
EVT_SPINCTRL( mgID_SPINCTRL, CNewTaskDlg::OnThSpin )
END_EVENT_TABLE()

#define  _MGSTR(s) wxGetApp().GetWxStr(s)
extern std::list<std::string> gSavePathHistory; //保存目录
CNewTaskDlg::CNewTaskDlg( MainFrame* parent, wxString defUrl, wxString defSavePath )
        : wxDialog( parent, -1, _MGSTR( _S_NEW_TASK ), wxDefaultPosition, wxSize( 400, 350 ) )
{
    m_pParent = parent;
    m_sUrl = defUrl;

    //对这个url分离用户名和密码

    if ( !m_sUrl.IsEmpty() )
    {
        CUrlParser par;
        std::string m_swap;

        if ( par.SetUrl( m_sUrl.mb_str( wxConvLocal ) ) )
        {
            m_sUser = wxString( par.GetUser().c_str(), wxConvLocal );
            m_sPass = wxString( par.GetPass().c_str(), wxConvLocal );
            m_sUrl = wxString( par.GetRawUrl().c_str(), wxConvLocal );
        }
    }

    m_sSavePath = defSavePath;

    if ( m_sSavePath.IsEmpty() )
    {
        m_sSavePath = wxString( gSavePathHistory.front().c_str(), wxConvLocal );

        if ( m_sSavePath.IsEmpty() )
        {
            std::string home;
            GetUserHome( home );
            m_sSavePath = wxString( home.c_str(), wxConvLocal );
        }
    }

    m_nThreadNum = 5;
    m_nSocksProxy = 0;
    m_nFtpProxy = 0;
    m_nHttpProxy = 0;
    m_nRunNow = 0; //run
    //这里准备一下代理列表
    InitProxyList();
    Init();
}

CNewTaskDlg::~CNewTaskDlg()
{
}

void CNewTaskDlg::Init()
{

    if ( m_sUrl.IsNull() && wxTheClipboard->Open() )
    {

        if ( wxTheClipboard->IsSupported( wxDF_TEXT ) )
        {

            wxTextDataObject text;

            if ( wxTheClipboard->GetData( text ) )
            {
                m_sUrl = text.GetText();
                CUrlParser upar;

                if ( !upar.SetUrl( std::string( m_sUrl.mb_str( wxConvLocal ) ) ) )
                {
                    m_sUrl = wxT( "" );
                }
                else if ( upar.GetFileName().empty() )
                {
                    m_sUrl = wxT( "" );
                }
            }
        }

        wxTheClipboard->Close();
    }

    //for border
    wxBoxSizer *top = new wxBoxSizer( wxVERTICAL );

    //old top
    wxBoxSizer *all = new wxBoxSizer( wxVERTICAL );

    //part1 url/savepath/rename
    wxBoxSizer *part1 = new wxStaticBoxSizer( wxVERTICAL, this, _MGSTR( _S_NEW_BASIC ) );

    //part2 run now/thread
    wxBoxSizer *part2 = new wxBoxSizer( wxHORIZONTAL );

    //part3 proxy
    wxBoxSizer *part3 = new wxBoxSizer( wxVERTICAL );

    //part4 user/pass
    wxBoxSizer *part4 = new wxBoxSizer( wxVERTICAL );

    //part5 button
    wxBoxSizer *part5 = new wxBoxSizer( wxVERTICAL );

    //part1
    wxBoxSizer *url = new wxBoxSizer( wxHORIZONTAL );

    wxBoxSizer *savepath = new wxBoxSizer( wxHORIZONTAL );

    wxBoxSizer *rename = new wxBoxSizer( wxHORIZONTAL );

    url->Add( new wxStaticText( this, -1, _MGSTR( _S_NEW_URL ), wxDefaultPosition, wxSize( 70, 25 ) ), 0, wxALIGN_LEFT );

    url->Add( new wxTextCtrl(
                  this,
                  -1,
                  wxT( "" ),
                  wxDefaultPosition,
                  wxSize( 320, 25 ),
                  0,
                  wxGenericValidator( &m_sUrl ) ), 0, wxEXPAND );

    savepath->Add( new wxStaticText( this, -1, _MGSTR( _S_NEW_SAVETO ), wxDefaultPosition, wxSize( 70, 25 ) ), 0, wxALIGN_LEFT );

    /*	savepath->Add(
    	new wxTextCtrl(this,-1,wxT(""),wxDefaultPosition,wxSize(285,25),0,wxGenericValidator(&m_sSavePath))
    	,0,wxEXPAND);
    */

    //从历史记录中导出目录
    DBGOUT( "history path size=" << gSavePathHistory.size() );

    wxArrayString pchoice;

    std::list<std::string>::const_iterator it;

    for ( it = gSavePathHistory.begin();it != gSavePathHistory.end();it++ )
    {
        if ( it->empty() )
        {
            continue;
        }
        else
        {
            wxString temp( it->c_str(), wxConvLocal );
            DBGOUT( "add a path to dropdown" );
            DBGOUT( temp );
            pchoice.Add( temp );
        }
    }

    savepath->Add( new wxComboBox( this, -1, wxT( "" ), wxDefaultPosition, wxSize( 285, 25 ), pchoice, 0, wxGenericValidator( &m_sSavePath ) ) );
    savepath->Add( new wxButton( this, mgID_PICKPATH, wxT( "..." ), wxDefaultPosition, wxSize( 35, 25 ) ), 0, wxALIGN_RIGHT );
    rename->Add( new wxStaticText( this, -1, _MGSTR( _S_NEW_RENAME ), wxDefaultPosition, wxSize( 70, 25 ) ), 0, wxALIGN_LEFT );
    rename->Add( new wxTextCtrl(
                     this,
                     -1,
                     wxT( "" ),
                     wxDefaultPosition,
                     wxSize( 320, 25 ),
                     0,
                     wxGenericValidator( &m_sRename ) ), 0, wxEXPAND );

    //add part1 to global
    part1->Add( url );
    part1->Add( savepath );
    part1->Add( rename );

    //part2

    wxBoxSizer *threads = new wxStaticBoxSizer( wxHORIZONTAL, this, _MGSTR( _S_NEW_THREADNUM ) );
    //	runnow->Add(new wxStaticText(this,-1,wxT("Threads:")),0,wxALIGN_LEFT);
    m_ThSpin = new wxSpinCtrl( this, mgID_SPINCTRL, wxT( "" ), wxDefaultPosition, wxSize( 120, 25 ) ); //
    m_ThSpin->SetRange( 1, 10 );
    m_ThSpin->SetValue( m_nThreadNum );
    threads->AddSpacer( 30 );
    threads->Add( m_ThSpin, 0, wxALIGN_LEFT );
    threads->AddSpacer( 30 );

    part2->Add( threads );
    part2->AddSpacer( 10 );

    wxString choices[ 2 ] =
        {
            _MGSTR( _S_NEW_YES ),
            _MGSTR( _S_NEW_NO ),
        };
    part2->Add(
        new wxRadioBox(
            this,
            -1,
            _MGSTR( _S_NEW_RUNNOW ),
            wxDefaultPosition,
            wxSize( 200, 25 ),
            2,
            choices,
            0,
            wxRA_SPECIFY_COLS,
            wxGenericValidator( &m_nRunNow ) ),
        0,
        wxEXPAND | wxALIGN_RIGHT );


    //part3 proxy

    wxStaticBoxSizer* proxy = new wxStaticBoxSizer( wxVERTICAL, this, _MGSTR( _S_NEW_PROXY ) );

    wxBoxSizer* socks = new wxBoxSizer( wxHORIZONTAL );
    wxBoxSizer* ftp = new wxBoxSizer( wxHORIZONTAL );
    wxBoxSizer* http = new wxBoxSizer( wxHORIZONTAL );

    socks->Add( new wxStaticText( this, -1, wxT( "SOCKS:" ), wxDefaultPosition, wxSize( 70, 25 ) ), 0, wxALIGN_LEFT );
    wxArrayString socksarray; //socks list
    //copy string

    for ( unsigned int i = 0;i < m_SocksProxyList.size();i++ )
    {
        socksarray.Add( m_SocksProxyList[ i ].showname );
    }

    socks->Add( new wxChoice(
                    this,
                    -1,
                    wxDefaultPosition,
                    wxSize( 300, 28 ),
                    socksarray,
                    0,
                    wxGenericValidator( &m_nSocksProxy ) ), 0, wxEXPAND );

    proxy->Add( socks );

    ftp->Add( new wxStaticText( this, -1, wxT( "FTP:" ), wxDefaultPosition, wxSize( 70, 25 ) ), 0, wxALIGN_LEFT );
    wxArrayString ftparray; //socks list
    //copy string

    for ( unsigned int i = 0;i < m_FtpProxyList.size();i++ )
    {
        ftparray.Add( m_FtpProxyList[ i ].showname );
    }

    ftp->Add( new wxChoice(
                  this,
                  -1,
                  wxDefaultPosition,
                  wxSize( 300, 28 ),
                  ftparray,
                  0,
                  wxGenericValidator( &m_nFtpProxy ) ), 0, wxEXPAND );
    proxy->Add( ftp );

    http->Add( new wxStaticText( this, -1, wxT( "HTTP:" ), wxDefaultPosition, wxSize( 70, 25 ) ), 0, wxALIGN_LEFT );
    wxArrayString httparray; //socks list
    //copy string

    for ( unsigned int i = 0;i < m_HttpProxyList.size();i++ )
    {
        httparray.Add( m_HttpProxyList[ i ].showname );
    }

    http->Add( new wxChoice(
                   this,
                   -1,
                   wxDefaultPosition,
                   wxSize( 300, 28 ),
                   httparray,
                   0,
                   wxGenericValidator( &m_nHttpProxy ) ), 0, wxEXPAND );
    proxy->Add( http );

    part3->Add( proxy, 0, wxEXPAND );

    //part4

    wxStaticBoxSizer* userpass = new wxStaticBoxSizer( wxHORIZONTAL, this, _MGSTR( _S_NEW_LOGIN ) );
    userpass->Add( new wxStaticText( this, -1, _MGSTR( _S_NEW_USER ), wxDefaultPosition, wxSize( 70, 25 ) ), 0, wxALIGN_RIGHT );
    userpass->Add( new wxTextCtrl(
                       this,
                       -1,
                       wxT( "" ),
                       wxDefaultPosition,
                       wxSize( 100, 25 ),
                       0,
                       wxGenericValidator( &m_sUser ) ), 0, wxALL );
    userpass->AddSpacer( 10 );
    userpass->Add( new wxStaticText( this, -1, _MGSTR( _S_NEW_PASS ), wxDefaultPosition, wxSize( 50, 25 ) ), 0, wxALIGN_RIGHT );
    userpass->Add( new wxTextCtrl(
                       this,
                       -1,
                       wxT( "" ),
                       wxDefaultPosition,
                       wxSize( 150, 25 ),
                       0,
                       wxGenericValidator( &m_sPass ) ), 0, wxALL );

    part4->Add( userpass, 0, wxEXPAND );

    //part5

    wxBoxSizer* but = new wxBoxSizer( wxHORIZONTAL );
    but->Add( new wxButton( this, wxID_CANCEL, wxT( "Cancel" ) ), 0, wxALL, 5 );
    but->Add( new wxButton( this, wxID_OK, wxT( "OK" ) ), 0, wxALL, 5 );
    part5->Add( but, 0, wxALIGN_RIGHT );

    all->Add( part1, 0, wxEXPAND );
    all->Add( part2, 0, wxEXPAND );
    all->Add( part3, 0, wxEXPAND );
    all->Add( part4, 0, wxEXPAND );
    all->Add( part5, 0, wxALIGN_RIGHT );

    top->Add( all, 1, wxEXPAND, 25 );
    top->Fit( this );
    SetSizer( top );

}

void CNewTaskDlg::OnPickPath( wxCommandEvent& event )
{
    wxDirDialog dlg( this, _MGSTR( _S_NEW_CHOOSEPATH ), m_sSavePath, wxDD_NEW_DIR_BUTTON );

    if ( dlg.ShowModal() == wxID_OK )
    {
        m_sSavePath = dlg.GetPath();
        TransferDataToWindow();
    }
}

void CNewTaskDlg::OnThSpin( wxSpinEvent& event )
{
    m_nThreadNum = m_ThSpin->GetValue();
}

void CNewTaskDlg::InitProxyList()
{
    m_SocksProxyList.clear();
    m_FtpProxyList.clear();
    m_HttpProxyList.clear();

    _PL temp;
    temp.name = "";
    temp.showname = _MGSTR( _S_NEW_NONE );

    m_SocksProxyList.push_back( temp );
    m_FtpProxyList.push_back( temp );
    m_HttpProxyList.push_back( temp );

    wxString tstr;
    //get proxy from parent
    int count = m_pParent->GetProxyCount();

    for ( int i = 0;i < count;i++ )
    {
        _ProxyAttr pa = m_pParent->GetProxy( i );

        switch ( pa.nType )
        {

            case 0:
            {
                temp.name = pa.sName;
                tstr.Printf( wxT( "%s|%s:%d|auto" ), pa.sName.c_str(), pa.sServer.c_str(), pa.nPort );
                temp.showname = tstr;
                m_SocksProxyList.push_back( temp );
            }

            break;

            case 1:
            {
                temp.name = pa.sName;
                tstr.Printf( wxT( "%s[%s:%d][v4]" ), pa.sName.c_str(), pa.sServer.c_str(), pa.nPort );
                temp.showname = tstr;
                m_SocksProxyList.push_back( temp );
            }

            break;

            case 2:
            {
                temp.name = pa.sName;
                tstr.Printf( wxT( "%s[%s:%d][v4a]" ), pa.sName.c_str(), pa.sServer.c_str(), pa.nPort );
                temp.showname = tstr;
                m_SocksProxyList.push_back( temp );
            }

            break;

            case 3:
            {
                temp.name = pa.sName;
                tstr.Printf( wxT( "%s[%s:%d][v5]" ), pa.sName.c_str(), pa.sServer.c_str(), pa.nPort );
                temp.showname = tstr;
                m_SocksProxyList.push_back( temp );
            }

            break;

            case 4:
            {
                temp.name = pa.sName;
                tstr.Printf( wxT( "%s[%s:%d]" ), pa.sName.c_str(), pa.sServer.c_str(), pa.nPort );
                temp.showname = tstr;
                m_FtpProxyList.push_back( temp );
            }

            break;

            case 5:
            {
                temp.name = pa.sName;
                tstr.Printf( wxT( "%s[%s:%d]" ), pa.sName.c_str(), pa.sServer.c_str(), pa.nPort );
                temp.showname = tstr;
                m_HttpProxyList.push_back( temp );
            }

            break;

            default:
            break;
        }
    }

    if ( m_SocksProxyList.size() == 1 )
    {
        m_SocksProxyList[ 0 ].showname = _MGSTR( _S_NEW_NOSOCKSPROXY );
    }

    if ( m_FtpProxyList.size() == 1 )
    {
        m_FtpProxyList[ 0 ].showname = _MGSTR( _S_NEW_NOFTPPROXY );
    }

    if ( m_HttpProxyList.size() == 1 )
    {
        m_HttpProxyList[ 0 ].showname = _MGSTR( _S_NEW_NOHTTPPROXY );
    }

}

void CNewTaskDlg::GetProxyName( std::string& socks, std::string& ftp, std::string& http )
{
    socks = ( m_SocksProxyList[ m_nSocksProxy ].name );
    ftp = ( m_FtpProxyList[ m_nFtpProxy ].name );
    http = ( m_HttpProxyList[ m_nHttpProxy ].name );
}

//如果user和pass不为空，要改写url返回
std::string CNewTaskDlg::GetUrl()
{
    return m_sUrl.mb_str( wxConvLocal );
}

